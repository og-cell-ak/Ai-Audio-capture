package com.monu.aiaudiocapture;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;

final class WavWriter {
    private WavWriter() {}

    static File openTemp(File cacheDir) throws IOException {
        File f = new File(cacheDir, "capture_" + System.currentTimeMillis() + ".wav");
        try (FileOutputStream out = new FileOutputStream(f)) {
            writeHeader(out, 48000, 1, 16, 0);
        }
        return f;
    }

    static void patchHeader(File file, long pcmBytes, int sampleRate, int channels, int bitsPerSample)
            throws IOException {
        try (RandomAccessFile raf = new RandomAccessFile(file, "rw")) {
            writeIntLE(raf, 4, (int) (36 + pcmBytes));
            writeIntLE(raf, 40, (int) pcmBytes);
            writeShortLE(raf, 22, channels);
            writeIntLE(raf, 24, sampleRate);
            int byteRate = sampleRate * channels * bitsPerSample / 8;
            writeIntLE(raf, 28, byteRate);
            int blockAlign = channels * bitsPerSample / 8;
            writeShortLE(raf, 32, blockAlign);
            writeShortLE(raf, 34, bitsPerSample);
        }
    }

    private static void writeHeader(FileOutputStream out, int sampleRate, int channels,
                                    int bitsPerSample, int dataSize) throws IOException {
        out.write(new byte[]{'R','I','F','F'});
        writeIntLE(out, 36 + dataSize);
        out.write(new byte[]{'W','A','V','E'});
        out.write(new byte[]{'f','m','t',' ',16,0,0,0,1,0});
        writeShortLE(out, channels);
        writeIntLE(out, sampleRate);
        int byteRate = sampleRate * channels * bitsPerSample / 8;
        writeIntLE(out, byteRate);
        writeShortLE(out, channels * bitsPerSample / 8);
        writeShortLE(out, bitsPerSample);
        out.write(new byte[]{'d','a','t','a'});
        writeIntLE(out, dataSize);
    }

    private static void writeIntLE(FileOutputStream out, int value) throws IOException {
        out.write(value & 0xff);
        out.write((value >>> 8) & 0xff);
        out.write((value >>> 16) & 0xff);
        out.write((value >>> 24) & 0xff);
    }

    private static void writeShortLE(FileOutputStream out, int value) throws IOException {
        out.write(value & 0xff);
        out.write((value >>> 8) & 0xff);
    }

    private static void writeIntLE(RandomAccessFile raf, long pos, int value) throws IOException {
        raf.seek(pos);
        raf.write(value & 0xff);
        raf.write((value >>> 8) & 0xff);
        raf.write((value >>> 16) & 0xff);
        raf.write((value >>> 24) & 0xff);
    }

    private static void writeShortLE(RandomAccessFile raf, long pos, int value) throws IOException {
        raf.seek(pos);
        raf.write(value & 0xff);
        raf.write((value >>> 8) & 0xff);
    }
}

package com.monu.aiaudiocapture;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;

import java.util.Locale;

public class MainActivity extends Activity {
    static final int PROJECTION_RESULT_OK = Activity.RESULT_OK;
    private static final int REQUEST_RECORD_AUDIO = 1001;
    private static final int REQUEST_PROJECTION = 1002;
    private static final int REQUEST_NOTIFICATIONS = 1003;

    private TextView statusText, levelText, modeText, resultText;
    private ProgressBar levelBar;
    private Button internalButton, micButton, stopButton, openChatButton, playButton, shareButton;
    private Handler handler;
    private Runnable poller;
    private String pendingMode = "internal";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        handler = new Handler(getMainLooper());
        poller = () -> { refresh(); handler.postDelayed(poller, 350); };
        handler.post(poller);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
    }

    private void buildUi() {
        ScrollView s = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(24), dp(18), dp(24));
        root.setBackgroundColor(0xff0b1020);
        s.addView(root);

        TextView badge = text("VERSION 3 • RECORDER + DIAGNOSTIC", 12, 0xff9ca9cc);
        root.addView(badge);
        TextView title = text("AI Audio Capture", 32, 0xffeef2ff);
        title.setTypeface(null, 1);
        root.addView(title, lp(-1, -2, 0, dp(5), 0, 0));
        TextView sub = text("Internal playback capture is the recommended route because your V2 All Eligible test successfully captured the AI voice. A microphone fallback is also included.", 14, 0xffaeb8d0);
        sub.setLineSpacing(0, 1.15f);
        root.addView(sub, lp(-1, -2, 0, 0, 0, dp(16)));

        LinearLayout card = card();
        root.addView(card);
        statusText = text("Ready", 16, 0xffeef2ff);
        card.addView(statusText, lp(-1, -2, 0, 0, 0, dp(8)));
        modeText = text("Mode: none", 13, 0xffaeb8d0);
        card.addView(modeText, lp(-1, -2, 0, 0, 0, dp(6)));
        levelText = text("Live level: 0%   Peak: 0%   Non-zero samples: 0", 13, 0xffaeb8d0);
        card.addView(levelText);
        levelBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        levelBar.setMax(100);
        card.addView(levelBar, lp(-1, dp(8), 0, dp(6), 0, dp(10)));
        resultText = text("Start Internal Playback to capture the same stream that worked in your V2 All Eligible test.", 12, 0xffaeb8d0);
        resultText.setLineSpacing(0, 1.2f);
        card.addView(resultText, lp(-1, -2, 0, 0, 0, dp(12)));

        internalButton = button("Capture Internal Playback (recommended)", 0xff7c5cff);
        internalButton.setOnClickListener(v -> startInternalCapture());
        card.addView(internalButton, lp(-1, dp(50), 0, 0, 0, dp(8)));

        micButton = button("Capture Speaker with Microphone (fallback)", 0xff1b2640);
        micButton.setOnClickListener(v -> startMicrophoneCapture());
        card.addView(micButton, lp(-1, dp(48), 0, 0, 0, dp(8)));

        stopButton = button("Stop & Save", 0xffff5d73);
        stopButton.setOnClickListener(v -> stopCapture());
        card.addView(stopButton, lp(-1, dp(48), 0, 0, 0, dp(8)));

        openChatButton = button("Open ChatGPT", 0xff1b2640);
        openChatButton.setOnClickListener(v -> openChatGPT());
        card.addView(openChatButton, lp(-1, dp(48), 0, 0, 0, dp(8)));

        playButton = button("Play Last Recording", 0xff1b2640);
        playButton.setOnClickListener(v -> openLastAudio());
        card.addView(playButton, lp(-1, dp(46), 0, 0, 0, dp(8)));

        shareButton = button("Share Last Recording", 0xff19c37d);
        shareButton.setTextColor(0xff06150f);
        shareButton.setOnClickListener(v -> shareLastAudio());
        card.addView(shareButton, lp(-1, dp(46), 0, 0, 0, dp(4)));

        LinearLayout info = card();
        root.addView(info, lp(-1, -2, 0, dp(14), 0, 0));
        TextView head = text("Best workflow for your ChatGPT test", 14, 0xffeef2ff);
        head.setTypeface(null, 1);
        info.addView(head, lp(-1, -2, 0, 0, 0, dp(8)));
        TextView how = text(
                "1. Tap Capture Internal Playback.\n\n" +
                "2. Approve Android's capture permission.\n\n" +
                "3. Tap Open ChatGPT.\n\n" +
                "4. Play the AI Read Aloud voice for 10–20 seconds.\n\n" +
                "5. Return here and watch the meter.\n\n" +
                "6. Tap Stop & Save.\n\n" +
                "If Internal Playback captures the AI voice reliably, use that mode. The microphone mode is a fallback that records the sound coming from the phone speaker.",
                13, 0xffaeb8d0);
        how.setLineSpacing(0, 1.25f);
        info.addView(how);

        TextView tip = text("Tip: keep the phone speaker volume high enough for the microphone fallback, and avoid Bluetooth headphones for that mode.", 12, 0xff9ca9cc);
        root.addView(tip, lp(-1, -2, 0, dp(12), 0, 0));

        setContentView(s);
        refreshButtons(false);
    }

    private void startInternalCapture() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            setStatus("Android 10+ is required for internal playback capture.");
            return;
        }
        pendingMode = "internal";
        requestRecordAudioThenContinue();
    }

    private void startMicrophoneCapture() {
        pendingMode = "microphone";
        requestRecordAudioThenContinue();
    }

    private void requestRecordAudioThenContinue() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO);
            return;
        }
        if ("internal".equals(pendingMode)) requestProjection();
        else startMicService();
    }

    private void requestProjection() {
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), REQUEST_PROJECTION);
    }

    private void startMicService() {
        Intent i = new Intent(this, CaptureService.class)
                .setAction(CaptureService.ACTION_START_MIC)
                .putExtra(CaptureService.EXTRA_MODE_NAME, "Speaker microphone");
        startForegroundService(i);
        setStatus("Microphone recording started. Play the ChatGPT AI voice now.");
        refreshButtons(true);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] p, int[] g) {
        super.onRequestPermissionsResult(requestCode, p, g);
        if (requestCode == REQUEST_RECORD_AUDIO) {
            if (g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) {
                if ("internal".equals(pendingMode)) requestProjection(); else startMicService();
            } else {
                setStatus("Microphone permission is required for this recorder.");
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int result, Intent data) {
        super.onActivityResult(requestCode, result, data);
        if (requestCode == REQUEST_PROJECTION) {
            if (result == RESULT_OK && data != null) {
                Intent i = new Intent(this, CaptureService.class)
                        .setAction(CaptureService.ACTION_START_INTERNAL)
                        .putExtra(CaptureService.EXTRA_PROJECTION_DATA, data)
                        .putExtra(CaptureService.EXTRA_MODE_NAME, "Internal playback");
                startForegroundService(i);
                setStatus("Internal playback capture started. Play the ChatGPT AI voice now.");
                refreshButtons(true);
            } else {
                setStatus("Android capture permission was cancelled.");
            }
        }
    }

    private void stopCapture() {
        startService(new Intent(this, CaptureService.class).setAction(CaptureService.ACTION_STOP));
    }

    private void openChatGPT() {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com/"))); }
        catch (Exception e) { Toast.makeText(this, "Could not open ChatGPT", Toast.LENGTH_SHORT).show(); }
    }

    private String getUri() {
        return getSharedPreferences(CaptureService.PREFS, MODE_PRIVATE)
                .getString(CaptureService.KEY_URI, null);
    }

    private void openLastAudio() {
        String u = getUri();
        if (u == null) { Toast.makeText(this, "No recording yet", Toast.LENGTH_SHORT).show(); return; }
        Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(u), "audio/wav");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(i); } catch (Exception e) { Toast.makeText(this, "No audio player found", Toast.LENGTH_SHORT).show(); }
    }

    private void shareLastAudio() {
        String u = getUri();
        if (u == null) { Toast.makeText(this, "No recording yet", Toast.LENGTH_SHORT).show(); return; }
        Intent i = new Intent(Intent.ACTION_SEND).setType("audio/wav");
        i.putExtra(Intent.EXTRA_STREAM, Uri.parse(u));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, "Share WAV"));
    }

    private void refresh() {
        SharedPreferences p = getSharedPreferences(CaptureService.PREFS, MODE_PRIVATE);
        String st = p.getString(CaptureService.KEY_STATUS, "Ready");
        float level = p.getFloat(CaptureService.KEY_LEVEL, 0);
        float peak = p.getFloat(CaptureService.KEY_PEAK, 0);
        long nz = p.getLong(CaptureService.KEY_NONZERO, 0);
        String mode = p.getString(CaptureService.KEY_TEST, "none");
        levelBar.setProgress((int) (Math.min(1f, level) * 100));
        levelText.setText(String.format(Locale.US, "Live level: %d%%   Peak: %d%%   Non-zero samples: %d", (int)(level*100), (int)(peak*100), nz));
        modeText.setText("Mode: " + mode);

        boolean running = "recording".equals(st);
        if (running) {
            statusText.setText("CAPTURING — play the AI voice now");
            resultText.setText("The meter is the live test. If it moves when the AI speaks, Android is exposing that audio to this recorder.");
        } else {
            statusText.setText(st);
            if (st.contains("AUDIO DETECTED")) {
                resultText.setText("Audio detected and saved. Play the WAV to confirm the AI voice is present.");
            } else if (st.contains("SILENCE")) {
                resultText.setText("No non-zero samples were captured. Try Internal Playback or the microphone fallback.");
            }
        }
        refreshButtons(running);
    }

    private void setStatus(String s) { statusText.setText(s); }

    private void refreshButtons(boolean recording) {
        boolean has = getUri() != null;
        internalButton.setEnabled(!recording);
        micButton.setEnabled(!recording);
        stopButton.setEnabled(recording);
        openChatButton.setEnabled(true);
        playButton.setEnabled(has);
        shareButton.setEnabled(has);
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(16), dp(16), dp(16));
        l.setBackgroundResource(R.drawable.card_bg);
        return l;
    }

    private Button button(String label, int bg) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(0xffffffff);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(bg));
        return b;
    }

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(l, t, r, b); return p;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override protected void onDestroy() {
        if (handler != null && poller != null) handler.removeCallbacks(poller);
        super.onDestroy();
    }
}

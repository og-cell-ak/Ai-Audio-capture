# AI Audio Capture V3

This version is built around the result from the user's V2 testing: the Android playback capture configuration containing all eligible usages successfully captured both the UI buzz and the AI Read Aloud voice.

## What changed from V2

1. Internal Playback Capture is now the primary one-tap recorder. It uses a fresh MediaProjection + AudioRecord session every time and matches all three Android-eligible playback usages in one capture configuration.
2. Added a Speaker Microphone fallback mode. This records the sound from the phone speaker through the phone microphone when internal playback capture is unavailable.
3. Added explicit foreground-service microphone permission/type for the fallback mode.
4. Every recording session fully releases AudioRecord and MediaProjection resources before the next session.
5. Added a live level/peak/sample meter so you can tell immediately whether audio is reaching the recorder.
6. Added Play Last Recording and Share Last Recording.
7. Saved WAV files are placed in Music/AI Audio Recorder.
8. Added Open ChatGPT button.
9. Version changed to 3.0.

## Recommended test

Use Internal Playback first because it matches the V2 All Eligible test that already captured the AI voice on this device.

1. Start Internal Playback.
2. Approve the Android capture prompt.
3. Open ChatGPT.
4. Play Read Aloud for 10–20 seconds.
5. Return to the recorder and watch the meter.
6. Stop & Save.
7. Play the saved WAV.

If Internal Playback stops capturing the AI voice but the microphone fallback works, use the microphone mode for actual recordings.

## GitHub Actions workflow for this ZIP

Use the following workflow in `.github/workflows/build-apk.yml` when the repository contains `AI-Audio-Capture-Diagnostic-V3.zip` at its root:

```yaml
name: Build Android APK V3

on:
  workflow_dispatch:
  push:
    paths:
      - "AI-Audio-Capture-Diagnostic-V3.zip"
      - ".github/workflows/build-apk.yml"

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Extract V3 project
        run: |
          rm -rf project
          mkdir project
          unzip -q AI-Audio-Capture-Diagnostic-V3.zip -d project

      - name: Set up Java
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "17"

      - name: Download Gradle 9.6.1
        run: |
          wget -q https://services.gradle.org/distributions/gradle-9.6.1-bin.zip
          unzip -q gradle-9.6.1-bin.zip
          echo "$PWD/gradle-9.6.1/bin" >> "$GITHUB_PATH"

      - name: Check Gradle
        run: gradle --version

      - name: Build APK
        working-directory: project
        run: gradle assembleDebug --no-daemon

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: AI-Audio-Capture-V3-APK
          path: project/app/build/outputs/apk/debug/*.apk
```

# AI Audio Capture — Diagnostic V2

Diagnostic build for investigating why one playback sound is capturable while another is not.

Tests available: All eligible, USAGE_MEDIA, USAGE_GAME, and USAGE_UNKNOWN. Each recording requests a fresh MediaProjection session and shows live level, peak, and non-zero sample count.

Android Playback Capture only exposes eligible playback when the source app uses an eligible audio usage and allows playback capture. This app is diagnostic and does not bypass another app's capture policy.

# AI Audio Capture Diagnostic V4

V4 targets the reproducible failure where capture works after a phone restart for recording #1 but recording #2 becomes silent.

## Main changes

* Requests a fresh MediaProjection consent/session for every internal recording.
* Registers MediaProjection.Callback before capture starts.
* Stops AudioRecord before stopping the projection.
* Releases AudioRecord and projection references completely.
* Waits for projection shutdown, with a short safety timeout, before stopping the service.
* Blocks overlapping capture while the previous session is finalizing.
* Adds a Reset Capture Engine button.
* Shows session lifecycle status such as ACTIVE, PROJECTION STOPPED, and CLEAN.
* Keeps the microphone fallback separate.

## GitHub Actions

Upload this ZIP as `AI-Audio-Capture-Diagnostic-V4.zip`, then use the included `.github/workflows/build-apk.yml`.

The workflow downloads Gradle 9.6.1 and builds `assembleDebug`.

## Testing

After installing V4:

1. Reboot the phone before the first test.
2. Start Internal Playback.
3. Play ChatGPT Read Aloud and record 10–20 seconds.
4. Stop and confirm the UI says the session is CLEAN.
5. Start a second Internal Playback session and play the same audio.
6. Repeat for a third session if possible.
7. If a session fails, capture a screenshot of the diagnostic status and live level.

Android requires fresh MediaProjection consent for each capture session on Android 14+, and apps must release resources after `MediaProjection.Callback.onStop()`. See: https://developer.android.com/media/grow/media-projection

package com.monu.aiaudiocapture;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.media.*;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.util.Log;

import java.io.*;

public class CaptureService extends Service {
    public static final String ACTION_START_INTERNAL = "com.monu.aiaudiocapture.START_INTERNAL";
    public static final String ACTION_START_MIC = "com.monu.aiaudiocapture.START_MIC";
    public static final String ACTION_STOP = "com.monu.aiaudiocapture.STOP";
    public static final String EXTRA_PROJECTION_DATA = "projection_data";
    public static final String EXTRA_MODE_NAME = "mode_name";

    public static final String PREFS = "capture_prefs";
    public static final String KEY_STATUS = "status";
    public static final String KEY_URI = "uri";
    public static final String KEY_LEVEL = "level";
    public static final String KEY_PEAK = "peak";
    public static final String KEY_NONZERO = "nonzero";
    public static final String KEY_TEST = "test";

    private static final String CHANNEL_ID = "ai_audio_capture_v4";
    private static final int NOTIFICATION_ID = 5003;
    private static final int SAMPLE_RATE = 48000;
    private static final int CHANNELS = 1;
    private static final int BITS = 16;

    private volatile boolean recording = false;
    private boolean finalizing = false;
    private Thread recordThread;
    private AudioRecord audioRecord;
    private MediaProjection mediaProjection;
    private File tempWav;
    private FileOutputStream tempOut;
    private long pcmBytes;
    private long nonZeroSamples;
    private int peakAbs;
    private String modeName = "Internal playback";
    private boolean micMode = false;
    private boolean projectionStopping = false;
    private MediaProjection.Callback projectionCallback;
    private long sessionId = 0;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopCapture("Stopped by user");
            return START_NOT_STICKY;
        }
        if (recording || finalizing) {
            setStatus("BUSY: previous capture session is still being released");
            return START_NOT_STICKY;
        }

        if (ACTION_START_MIC.equals(action)) {
            modeName = intent.getStringExtra(EXTRA_MODE_NAME);
            if (modeName == null) modeName = "Speaker microphone";
            micMode = true;
            startMicrophoneCapture();
        } else if (ACTION_START_INTERNAL.equals(action)) {
            Intent data = getParcelableExtraCompat(intent, EXTRA_PROJECTION_DATA);
            modeName = intent.getStringExtra(EXTRA_MODE_NAME);
            if (modeName == null) modeName = "Internal playback";
            micMode = false;
            if (data == null) {
                setStatus("Error: missing Android capture permission data");
                stopSelf();
            } else {
                startInternalCapture(data);
            }
        }
        return START_NOT_STICKY;
    }

    private void startInternalCapture(Intent data) {
        try {
            startAsForeground("Starting internal playback capture…", true);
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) throw new IllegalStateException("Android 10+ required");

            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            mediaProjection = mpm.getMediaProjection(MainActivity.PROJECTION_RESULT_OK, data);
            if (mediaProjection == null) throw new IllegalStateException("Android returned no MediaProjection");

            final long thisSession = ++sessionId;
            projectionCallback = new MediaProjection.Callback() {
                @Override public void onStop() {
                    projectionStopping = true;
                    setStatus("Session #" + thisSession + ": PROJECTION STOPPED");
                    if (recording || finalizing) finishAfterProjectionStop("Android ended the MediaProjection session");
                }
            };
            mediaProjection.registerCallback(projectionCallback, new Handler(Looper.getMainLooper()));

            AudioPlaybackCaptureConfiguration config = new AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build();

            AudioFormat format = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                    .build();

            int min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) throw new IllegalStateException("Unsupported capture format");

            audioRecord = new AudioRecord.Builder()
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(Math.max(min * 4, 16384))
                    .setAudioPlaybackCaptureConfig(config)
                    .build();

            if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) {
                throw new IllegalStateException("Internal playback AudioRecord failed to initialize");
            }
            beginRecording();
        } catch (SecurityException e) {
            Log.e("CaptureService", "Internal capture blocked", e);
            stopCapture("Android/source-app capture policy blocked internal audio");
        } catch (Exception e) {
            Log.e("CaptureService", "Internal start failed", e);
            stopCapture("Internal capture failed: " + e.getMessage());
        }
    }

    private void startMicrophoneCapture() {
        try {
            startAsForeground("Starting speaker microphone capture…", false);
            AudioFormat format = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                    .build();
            int min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) throw new IllegalStateException("Unsupported microphone format");

            audioRecord = new AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(Math.max(min * 4, 16384))
                    .build();

            if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) {
                throw new IllegalStateException("Microphone AudioRecord failed to initialize");
            }
            beginRecording();
        } catch (SecurityException e) {
            Log.e("CaptureService", "Microphone permission denied", e);
            stopCapture("Microphone permission denied");
        } catch (Exception e) {
            Log.e("CaptureService", "Microphone start failed", e);
            stopCapture("Microphone capture failed: " + e.getMessage());
        }
    }

    private void beginRecording() throws IOException {
        tempWav = WavWriter.openTemp(getCacheDir());
        tempOut = new FileOutputStream(tempWav, true);
        pcmBytes = 0;
        nonZeroSamples = 0;
        peakAbs = 0;
        finalizing = false;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putFloat(KEY_LEVEL, 0)
                .putFloat(KEY_PEAK, 0)
                .putLong(KEY_NONZERO, 0)
                .putString(KEY_TEST, modeName)
                .apply();

        recording = true;
        audioRecord.startRecording();
        setStatus("Session #" + sessionId + ": recording / AudioRecord ACTIVE");
        updateNotification("Recording " + modeName + "…");
        recordThread = new Thread(this::recordLoop, "AI-Audio-Capture-V4");
        recordThread.start();
    }

    private void recordLoop() {
        byte[] buffer = new byte[16384];
        try {
            while (recording) {
                int read = audioRecord.read(buffer, 0, buffer.length, AudioRecord.READ_BLOCKING);
                if (read > 0) {
                    tempOut.write(buffer, 0, read);
                    pcmBytes += read;

                    int samples = read / 2;
                    double sumSquares = 0;
                    int blockPeak = 0;
                    for (int i = 0; i + 1 < read; i += 2) {
                        short sample = (short)((buffer[i] & 0xff) | (buffer[i + 1] << 8));
                        int abs = Math.abs((int) sample);
                        if (abs > 0) nonZeroSamples++;
                        if (abs > blockPeak) blockPeak = abs;
                        if (abs > peakAbs) peakAbs = abs;
                        sumSquares += (double) sample * sample;
                    }

                    float rms = samples == 0 ? 0f : (float)Math.sqrt(sumSquares / samples) / 32768f;
                    float peak = Math.min(1f, peakAbs / 32768f);
                    float level = Math.min(1f, rms * 12f);
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                            .putFloat(KEY_LEVEL, level)
                            .putFloat(KEY_PEAK, peak)
                            .putLong(KEY_NONZERO, nonZeroSamples)
                            .apply();
                } else if (read == AudioRecord.ERROR_DEAD_OBJECT || read == AudioRecord.ERROR_INVALID_OPERATION) {
                    break;
                }
            }
        } catch (Exception e) {
            Log.e("CaptureService", "Read loop failed", e);
        }
        if (recording) stopCapture("Capture stream ended");
    }

    private synchronized void stopCapture(String status) {
        if (finalizing) return;
        finalizing = true;
        recording = false;
        setStatus("Session #" + sessionId + ": releasing AudioRecord…");

        try { if (audioRecord != null) audioRecord.stop(); } catch (Exception ignored) {}
        if (recordThread != null && Thread.currentThread() != recordThread) {
            try { recordThread.join(1500); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
        recordThread = null;

        try { if (tempOut != null) tempOut.close(); } catch (Exception ignored) {}
        tempOut = null;

        String finalStatus = status;
        if (tempWav != null && tempWav.exists() && pcmBytes > 0) {
            try {
                WavWriter.patchHeader(tempWav, pcmBytes, SAMPLE_RATE, CHANNELS, BITS);
                Uri saved = saveToMusicFolder(tempWav);
                if (saved != null) {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                            .putString(KEY_URI, saved.toString())
                            .apply();
                    finalStatus = nonZeroSamples == 0 ? modeName + ": SILENCE" : modeName + ": AUDIO DETECTED";
                } else finalStatus = modeName + ": recording made, save failed";
            } catch (Exception e) { finalStatus = "Save failed: " + e.getMessage(); }
        }

        try { if (audioRecord != null) audioRecord.release(); } catch (Exception ignored) {}
        audioRecord = null;
        if (tempWav != null) { try { tempWav.delete(); } catch (Exception ignored) {} }
        tempWav = null;

        // MediaProjection is single-use on Android 14+. Stop it only after AudioRecord is released.
        if (mediaProjection != null && !projectionStopping) {
            try { mediaProjection.stop(); } catch (Exception ignored) {}
            // onStop() will complete the projection lifecycle. A timeout is only a safety net.
            final Handler h = new Handler(Looper.getMainLooper());
            final String statusForCallback = finalStatus;
            h.postDelayed(() -> finishAfterProjectionStop(statusForCallback), 1200);
        } else {
            finishAfterProjectionStop(finalStatus);
        }
    }

    private synchronized void finishAfterProjectionStop(String status) {
        if (!finalizing && mediaProjection == null) return;
        projectionStopping = true;
        try {
            if (mediaProjection != null && projectionCallback != null) {
                try { mediaProjection.unregisterCallback(projectionCallback); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
        mediaProjection = null;
        projectionCallback = null;
        finalizing = false;
        setStatus("Session #" + sessionId + ": CLEAN — ready for a NEW Android capture session");
        updateNotification("Ready");
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private Uri saveToMusicFolder(File source) throws IOException {
        String safe = modeName.replaceAll("[^A-Za-z0-9]+", "_");
        String name = "AI_Audio_V4_" + safe + "_" + System.currentTimeMillis() + ".wav";
        ContentResolver resolver = getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.Audio.Media.DISPLAY_NAME, name);
        values.put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/AI Audio Recorder");
            values.put(MediaStore.Audio.Media.IS_PENDING, 1);
        }
        Uri uri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) return null;

        try (FileInputStream in = new FileInputStream(source); OutputStream out = resolver.openOutputStream(uri)) {
            if (out == null) throw new IOException("Destination unavailable");
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } catch (Exception e) {
            resolver.delete(uri, null, null);
            throw e;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues done = new ContentValues();
            done.put(MediaStore.Audio.Media.IS_PENDING, 0);
            resolver.update(uri, done, null, null);
        }
        return uri;
    }

    private void setStatus(String value) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_STATUS, value).apply();
    }

    private void startAsForeground(String text, boolean mediaProjectionType) {
        Intent stop = new Intent(this, CaptureService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 30,
                stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setContentTitle("AI Audio Capture V4")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Stop", pi).build());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            int type = mediaProjectionType
                    ? ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                    : ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
            startForeground(NOTIFICATION_ID, builder.build(), type);
        } else {
            startForeground(NOTIFICATION_ID, builder.build());
        }
    }

    private void updateNotification(String text) {
        NotificationManager manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setContentTitle("AI Audio Capture V4")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(recording);
        manager.notify(NOTIFICATION_ID, builder.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "AI Audio Capture", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private Intent getParcelableExtraCompat(Intent intent, String key) {
        if (Build.VERSION.SDK_INT >= 33) return intent.getParcelableExtra(key, Intent.class);
        return intent.getParcelableExtra(key);
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}

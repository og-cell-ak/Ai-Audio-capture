package com.monu.aiaudiocapture;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.MediaStore;
import android.util.Log;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CaptureService extends Service {
    public static final String ACTION_START = "com.monu.aiaudiocapture.START";
    public static final String ACTION_STOP = "com.monu.aiaudiocapture.STOP";
    public static final String EXTRA_PROJECTION_DATA = "projection_data";
    public static final String PREFS = "capture_prefs";
    public static final String KEY_STATUS = "status";
    public static final String KEY_URI = "uri";
    public static final String KEY_FILENAME = "filename";
    public static final String KEY_LEVEL = "level";

    private static final String CHANNEL_ID = "ai_audio_capture";
    private static final int NOTIFICATION_ID = 5001;
    private static final int SAMPLE_RATE = 48000;
    private static final int CHANNELS = 1;
    private static final int BITS = 16;

    private volatile boolean recording;
    private Thread recordThread;
    private AudioRecord audioRecord;
    private MediaProjection mediaProjection;
    private File tempWav;
    private FileOutputStream tempOut;
    private long pcmBytes;
    private long nonZeroSamples;
    private long totalSamples;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopCapture("Stopped");
            return START_NOT_STICKY;
        }
        if (intent != null && ACTION_START.equals(intent.getAction())) {
            if (!recording) {
                Intent projectionData = getParcelableExtraCompat(intent, EXTRA_PROJECTION_DATA);
                if (projectionData == null) {
                    setStatus("Error: missing projection permission");
                    stopSelf();
                } else {
                    startCapture(projectionData);
                }
            }
        }
        return START_NOT_STICKY;
    }

    private void startCapture(Intent projectionData) {
        try {
            startAsForeground("Preparing audio capture…");

            MediaProjectionManager mpm =
                    (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            mediaProjection = mpm.getMediaProjection(
                    MainActivity.PROJECTION_RESULT_OK, projectionData);
            if (mediaProjection == null) {
                throw new IllegalStateException("Android did not return a media projection.");
            }

            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                throw new IllegalStateException("Playback capture requires Android 10 or newer.");
            }

            AudioPlaybackCaptureConfiguration config = new AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build();

            AudioFormat format = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                    .build();

            int minBuffer = AudioRecord.getMinBufferSize(
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT);
            if (minBuffer <= 0) {
                throw new IllegalStateException("This phone rejected the playback capture audio format.");
            }

            audioRecord = new AudioRecord.Builder()
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(Math.max(minBuffer * 2, 8192))
                    .setAudioPlaybackCaptureConfig(config)
                    .build();

            if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) {
                throw new IllegalStateException("Audio capture could not be initialized.");
            }

            tempWav = WavWriter.openTemp(getCacheDir());
            tempOut = new FileOutputStream(tempWav, true);
            pcmBytes = 0;
            nonZeroSamples = 0;
            totalSamples = 0;
            recording = true;

            audioRecord.startRecording();
            updateNotification("Recording ChatGPT/app audio…");
            setStatus("recording");

            recordThread = new Thread(this::recordLoop, "AudioPlaybackCapture");
            recordThread.start();
        } catch (SecurityException e) {
            Log.e("CaptureService", "SecurityException", e);
            stopCapture("Capture blocked by Android/app permissions");
        } catch (Exception e) {
            Log.e("CaptureService", "Could not start capture", e);
            stopCapture("Could not start: " + e.getMessage());
        }
    }

    private void recordLoop() {
        byte[] buffer = new byte[8192];
        try {
            while (recording) {
                int read = audioRecord.read(buffer, 0, buffer.length, AudioRecord.READ_BLOCKING);
                if (read > 0) {
                    tempOut.write(buffer, 0, read);
                    pcmBytes += read;

                    // Lightweight level detection for the UI.
                    long absSum = 0;
                    int samples = read / 2;
                    for (int i = 0; i + 1 < read; i += 2) {
                        short sample = (short) ((buffer[i] & 0xff) | (buffer[i + 1] << 8));
                        if (sample != 0) nonZeroSamples++;
                        absSum += Math.abs((long) sample);
                    }
                    totalSamples += samples;
                    float level = samples == 0 ? 0f : Math.min(1f, (absSum / (float) samples) / 32768f * 8f);
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putFloat(KEY_LEVEL, level).apply();
                } else if (read == AudioRecord.ERROR_DEAD_OBJECT || read == AudioRecord.ERROR_INVALID_OPERATION) {
                    break;
                }
            }
        } catch (Exception e) {
            Log.e("CaptureService", "Record loop failed", e);
        }

        if (recording) {
            stopCapture("Audio capture ended");
        }
    }

    private void stopCapture(String status) {
        boolean wasRecording = recording;
        recording = false;

        try { if (audioRecord != null) audioRecord.stop(); } catch (Exception ignored) {}
        if (recordThread != null && Thread.currentThread() != recordThread) {
            try { recordThread.join(700); } catch (InterruptedException ignored) {}
        }
        recordThread = null;

        try { if (tempOut != null) tempOut.close(); } catch (Exception ignored) {}
        tempOut = null;

        String finalStatus = status;
        if (wasRecording && tempWav != null && tempWav.exists() && pcmBytes > 0) {
            try {
                WavWriter.patchHeader(tempWav, pcmBytes, SAMPLE_RATE, CHANNELS, BITS);
                Uri saved = saveToMusicFolder(tempWav);
                if (saved != null) {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                            .putString(KEY_URI, saved.toString())
                            .putString(KEY_FILENAME, getDisplayName(saved))
                            .apply();
                    if (nonZeroSamples == 0) {
                        finalStatus = "Saved, but no playback audio was detected";
                    } else {
                        finalStatus = "saved";
                    }
                } else {
                    finalStatus = "Recording made, but saving failed";
                }
            } catch (Exception e) {
                Log.e("CaptureService", "Save failed", e);
                finalStatus = "Saving failed: " + e.getMessage();
            }
        }

        try { if (mediaProjection != null) mediaProjection.stop(); } catch (Exception ignored) {}
        mediaProjection = null;
        if (audioRecord != null) {
            audioRecord.release();
            audioRecord = null;
        }
        if (tempWav != null) tempWav.delete();
        tempWav = null;

        setStatus(finalStatus);
        updateNotification("Ready");
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private Uri saveToMusicFolder(File source) throws IOException {
        String name = "AI_Audio_" + System.currentTimeMillis() + ".wav";
        ContentResolver resolver = getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.Audio.Media.DISPLAY_NAME, name);
        values.put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav");
        values.put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/AI Audio Recorder");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.put(MediaStore.Audio.Media.IS_PENDING, 1);
        }

        Uri uri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) return null;

        try (FileInputStream in = new FileInputStream(source);
             FileOutputStream out = (FileOutputStream) resolver.openOutputStream(uri)) {
            if (out == null) throw new IOException("Could not open destination");
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } catch (Exception e) {
            resolver.delete(uri, null, null);
            throw e;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues done = new ContentValues();
            done.put(MediaStore.Audio.Media.IS_PENDING, 0);
            resolver.update(uri, done, null, null);
        }
        return uri;
    }

    private String getDisplayName(Uri uri) {
        return "AI Audio recording.wav";
    }

    private void setStatus(String status) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(KEY_STATUS, status)
                .apply();
    }

    private void startAsForeground(String text) {
        Intent stopIntent = new Intent(this, CaptureService.class).setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(
                this, 10, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder nb = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        Notification notification = nb
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("AI Audio Capture")
                .setContentText(text)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(new Notification.Action.Builder(
                        android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_media_pause),
                        "Stop", stopPending).build())
                .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void updateNotification(String text) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            PendingIntent contentIntent = PendingIntent.getActivity(
                    this, 12, new Intent(this, MainActivity.class),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder nb = new Notification.Builder(this, CHANNEL_ID);
            Notification n = nb
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentTitle("AI Audio Capture")
                    .setContentText(text)
                    .setOngoing(recording)
                    .setContentIntent(contentIntent)
                    .build();
            nm.notify(NOTIFICATION_ID, n);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "AI Audio Capture", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Playback audio capture controls");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    @SuppressWarnings("deprecation")
    private static Intent getParcelableExtraCompat(Intent intent, String key) {
        if (Build.VERSION.SDK_INT >= 33) {
            return intent.getParcelableExtra(key, Intent.class);
        }
        return intent.getParcelableExtra(key);
    }

    @Override
    public void onDestroy() {
        if (recording || audioRecord != null || mediaProjection != null) {
            stopCapture("Destroyed");
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

package com.monu.aiaudiocapture;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    static final int PROJECTION_RESULT_OK = Activity.RESULT_OK;

    private TextView statusText;
    private TextView levelText;
    private TextView savedText;
    private Button startButton;
    private Button stopButton;
    private Button openChatGptButton;
    private Button playButton;
    private Button shareButton;
    private ProgressBar levelBar;
    private android.os.Handler handler;
    private Runnable poller;

    private static final int REQUEST_RECORD_AUDIO = 1001;
    private static final int REQUEST_PROJECTION = 1002;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        handler = new android.os.Handler(getMainLooper());
        poller = () -> {
            refreshFromPrefs();
            handler.postDelayed(poller, 500);
        };
        handler.post(poller);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_RECORD_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                requestProjection();
            } else {
                setStatus("Microphone permission is required by Android for playback capture.");
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PROJECTION) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                Intent serviceIntent = new Intent(this, CaptureService.class)
                        .setAction(CaptureService.ACTION_START)
                        .putExtra(CaptureService.EXTRA_PROJECTION_DATA, data);
                startForegroundService(serviceIntent);
                setStatus("Recording started. Now play the ChatGPT AI voice.");
                refreshButtons(true);
            } else {
                setStatus("Screen/audio capture permission was cancelled.");
            }
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(24), dp(18), dp(24));
        root.setBackgroundColor(android.graphics.Color.rgb(11,16,32));
        scroll.addView(root);

        TextView eyebrow = text("ANDROID AUDIO TOOL", 12, 0xff9ca9cc);
        eyebrow.setAllCaps(true);
        root.addView(eyebrow);

        TextView title = text("AI Audio Capture", 32, 0xffeef2ff);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title, lp(-1, -2, 0, dp(5), 0, 0));

        TextView sub = text("Capture permitted playback audio from another app, save it as WAV, and reuse the file.", 14, 0xffaeb8d0);
        sub.setLineSpacing(0, 1.15f);
        root.addView(sub, lp(-1, -2, 0, 0, 0, dp(18)));

        LinearLayout card = card();
        root.addView(card);

        statusText = text("Ready. Tap Start Capture.", 15, 0xffeef2ff);
        statusText.setLineSpacing(0, 1.1f);
        card.addView(statusText, lp(-1, -2, 0, 0, 0, dp(12)));

        levelText = text("Audio level: 0%", 12, 0xffaeb8d0);
        card.addView(levelText);
        levelBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        levelBar.setMax(100);
        levelBar.setProgress(0);
        card.addView(levelBar, lp(-1, dp(8), 0, dp(6), 0, dp(15)));

        startButton = button("Start Capture", 0xff7c5cff);
        startButton.setOnClickListener(v -> beginCapture());
        card.addView(startButton, lp(-1, dp(50), 0, 0, 0, dp(8)));

        stopButton = button("Stop & Save", 0xffff5d73);
        stopButton.setOnClickListener(v -> stopCapture());
        card.addView(stopButton, lp(-1, dp(50), 0, 0, 0, dp(8)));

        openChatGptButton = button("Open ChatGPT", 0xff1b2640);
        openChatGptButton.setOnClickListener(v -> openChatGPT());
        card.addView(openChatGptButton, lp(-1, dp(50), 0, 0, 0, dp(14)));

        savedText = text("No recording yet.", 13, 0xffaeb8d0);
        card.addView(savedText);

        playButton = button("Play Last Audio", 0xff1b2640);
        playButton.setOnClickListener(v -> openLastAudio(Intent.ACTION_VIEW));
        card.addView(playButton, lp(-1, dp(46), 0, dp(10), 0, dp(8)));

        shareButton = button("Share Last Audio", 0xff19c37d);
        shareButton.setTextColor(0xff06150f);
        shareButton.setOnClickListener(v -> shareLastAudio());
        card.addView(shareButton, lp(-1, dp(46), 0, 0, 0, dp(4)));

        LinearLayout info = card();
        root.addView(info, lp(-1, -2, 0, dp(14), 0, 0));
        TextView heading = text("How to use", 14, 0xffeef2ff);
        heading.setTypeface(null, android.graphics.Typeface.BOLD);
        info.addView(heading, lp(-1, -2, 0, 0, 0, dp(8)));
        TextView how = text(
                "1. Tap Start Capture and approve Android's capture prompt.\n\n" +
                "2. Tap Open ChatGPT and play the generated voice.\n\n" +
                "3. Return here and tap Stop & Save. The WAV is saved in Music/AI Audio Recorder.\n\n" +
                "Important: Android only exposes playback audio when the source app allows playback capture. If the saved file is silent, ChatGPT/the device audio path is blocking capture.",
                13, 0xffaeb8d0);
        how.setLineSpacing(0, 1.25f);
        info.addView(how);

        setContentView(scroll);
        refreshButtons(false);
    }

    private void beginCapture() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            setStatus("This app requires Android 10 (API 29) or newer.");
            return;
        }

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO);
            return;
        }
        requestProjection();
    }

    private void requestProjection() {
        MediaProjectionManager manager =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_PROJECTION);
    }

    private void stopCapture() {
        Intent stop = new Intent(this, CaptureService.class).setAction(CaptureService.ACTION_STOP);
        startService(stop);
    }

    private void openChatGPT() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com/"));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Could not open ChatGPT", Toast.LENGTH_SHORT).show();
        }
    }

    private void openLastAudio(String action) {
        String uri = getSharedPreferences(CaptureService.PREFS, MODE_PRIVATE)
                .getString(CaptureService.KEY_URI, null);
        if (uri == null) {
            Toast.makeText(this, "No saved recording yet", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(action);
        intent.setDataAndType(Uri.parse(uri), "audio/wav");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No audio player found", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareLastAudio() {
        String uri = getSharedPreferences(CaptureService.PREFS, MODE_PRIVATE)
                .getString(CaptureService.KEY_URI, null);
        if (uri == null) {
            Toast.makeText(this, "No saved recording yet", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("audio/wav");
        share.putExtra(Intent.EXTRA_STREAM, Uri.parse(uri));
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(share, "Use recording with…"));
    }

    private void refreshFromPrefs() {
        android.content.SharedPreferences prefs = getSharedPreferences(CaptureService.PREFS, MODE_PRIVATE);
        String status = prefs.getString(CaptureService.KEY_STATUS, "Ready. Tap Start Capture.");
        float level = prefs.getFloat(CaptureService.KEY_LEVEL, 0f);
        float pct = Math.min(100f, level * 100f);
        levelBar.setProgress((int) pct);
        levelText.setText(String.format(Locale.US, "Audio level: %d%%", (int)pct));

        String uri = prefs.getString(CaptureService.KEY_URI, null);
        if (uri != null) {
            savedText.setText("Last recording: saved to Music/AI Audio Recorder");
        }

        if ("recording".equals(status)) {
            statusText.setText("Recording is active. Play the ChatGPT AI voice now.");
            refreshButtons(true);
        } else if ("saved".equals(status)) {
            statusText.setText("Saved successfully. Your WAV file is ready to use.");
            refreshButtons(false);
        } else if (status.contains("no playback audio")) {
            statusText.setText("Saved, but no playback audio was detected. The source app may block capture.");
            refreshButtons(false);
        } else if (status.startsWith("Could not start") || status.startsWith("Capture blocked") || status.startsWith("Error")) {
            statusText.setText(status);
            refreshButtons(false);
        }
    }

    private void setStatus(String value) {
        statusText.setText(value);
    }

    private void refreshButtons(boolean recording) {
        if (startButton == null) return;
        startButton.setEnabled(!recording);
        stopButton.setEnabled(recording);
        openChatGptButton.setEnabled(recording || true);
        playButton.setEnabled(getSharedPreferences(CaptureService.PREFS, MODE_PRIVATE).contains(CaptureService.KEY_URI));
        shareButton.setEnabled(getSharedPreferences(CaptureService.PREFS, MODE_PRIVATE).contains(CaptureService.KEY_URI));
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(16), dp(16), dp(16));
        l.setBackgroundResource(com.monu.aiaudiocapture.R.drawable.card_bg);
        return l;
    }

    private Button button(String label, int bg) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(0xffffffff);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(bg));
        return b;
    }

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(l, t, r, b);
        return p;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        if (handler != null && poller != null) handler.removeCallbacks(poller);
        super.onDestroy();
    }
}

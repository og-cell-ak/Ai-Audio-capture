# AI Audio Capture for Android

Native Android recorder for permitted playback audio.

## What it does

The app uses Android's MediaProjection + AudioPlaybackCapture APIs to capture playback audio that Android exposes to other apps, then writes a PCM16 WAV file into `Music/AI Audio Recorder`.

## Device requirements

Android 10 (API 29) or newer.

## Use

1. Build and install the APK.
2. Tap Start Capture.
3. Approve Android's capture prompt.
4. Tap Open ChatGPT and play the generated voice.
5. Return to the recorder and tap Stop & Save.
6. Use Play Last Audio or Share Last Audio. The file is also in Music/AI Audio Recorder.

## Important limitation

Android does not guarantee access to another app's playback. The source app must use a capturable audio usage and permit playback capture. A silent recording means the source app/device audio path did not expose the audio. This app cannot and does not bypass that restriction.

## Building

Open the project in Android Studio. The project is configured for Android Gradle Plugin 9.4.0 / Gradle 9.6.0 and compile SDK 36. Open the project in Android Studio, let Gradle sync, then use **Build > Build App(s) > Build APK(s)**. The APK will be under `app/build/outputs/apk/debug/`. This workspace does not include the Android SDK/build toolchain, so I could not produce the APK binary directly here.
